import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class AffiliationTypeSheet extends StatelessWidget {
  final String current;
  final List<String> options;
  const AffiliationTypeSheet({
    super.key,
    required this.current,
    required this.options,
  });

  @override
  Widget build(BuildContext context) {
    final selected = RxString(current);

    return SafeArea(
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
          padding: EdgeInsets.fromLTRB(12.w, 0, 12.w, 12.h),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.r),
            child: Padding(
              padding: EdgeInsets.fromLTRB(16.w, 10.h, 16.w, 16.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 60.w,
                    height: 5.h,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE5E7EB),
                      borderRadius: BorderRadius.circular(3.r),
                    ),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    'choose'.tr,
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  const Divider(height: 1),

                  SizedBox(height: 8.h),
                  ...options.map(
                    (label) => Obx(() {
                      final isSel = selected.value == label;
                      return InkWell(
                        onTap: () => selected.value = label,
                        borderRadius: BorderRadius.circular(10.r),
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 10.h),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.drag_indicator_rounded,
                                color: Color(0xFF111827),
                              ),
                              SizedBox(width: 10.w),
                              Expanded(
                                child: Text(
                                  _affText(label).tr,
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              Icon(
                                isSel
                                    ? Icons.radio_button_checked
                                    : Icons.radio_button_off,
                                color: isSel
                                    ? const Color(0xFFE53935)
                                    : const Color(0xFF9CA3AF),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ),

                  SizedBox(height: 12.h),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE53935),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                      ),
                      onPressed: () => Get.back(result: selected.value),
                      child: Text(
                        'done'.tr,
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // map raw labels to translation keys (so you can localize freely)
  String _affText(String raw) {
    switch (raw) {
      case 'Hospital':
        return 'aff_hospital';
      case 'Pharmacy':
        return 'aff_pharmacy';
      case 'NGO/Clinic':
        return 'aff_ngo_clinic';
      case 'Community Health Volunteer':
        return 'aff_chv';
      case 'Other (specify manually)':
        return 'aff_other';
      default:
        return raw; // fallback
    }
  }
}
