import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'professional_info_edit_controller.dart';

class ProfessionalInfoEditView extends GetView<ProfessionalInfoEditController> {
  const ProfessionalInfoEditView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
        centerTitle: true,
        title: Text('edit_professional_info'.tr),
      ),
      body: Form(
        key: controller.formKey,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(16.w),
                children: [
                  // Section: Professional Information
                  _sectionTitle('professional_information'.tr),
                  _fieldLabel('affiliation_type_star'.tr),
                  Obx(
                    () => InkWell(
                      onTap: controller.openAffiliationSheet,
                      borderRadius: BorderRadius.circular(10.r),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 12.w,
                          vertical: 12.h,
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xFFE5E7EB)),
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(controller.selectedAffiliation.value),
                            ),
                            const Icon(Icons.expand_more_rounded),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 16.h),

                  // Section: Affiliation Details
                  _sectionTitle('affiliation_details'.tr),
                  _fieldLabel('org_business_name_star'.tr),
                  TextFormField(
                    controller: controller.orgCtrl,
                    decoration: _inputDecoration(hint: 'org_name_hint'.tr),
                    validator: (v) =>
                        (v?.trim().isEmpty ?? true) ? 'required'.tr : null,
                  ),
                  SizedBox(height: 12.h),
                  _fieldLabel('your_role_star'.tr),
                  TextFormField(
                    controller: controller.roleCtrl,
                    decoration: _inputDecoration(hint: 'role_hint'.tr),
                    validator: (v) =>
                        (v?.trim().isEmpty ?? true) ? 'required'.tr : null,
                  ),
                  SizedBox(height: 12.h),
                  _fieldLabel('zone_area_star'.tr),
                  TextFormField(
                    controller: controller.zoneCtrl,
                    decoration: _inputDecoration(hint: 'zone_hint'.tr),
                    validator: (v) =>
                        (v?.trim().isEmpty ?? true) ? 'required'.tr : null,
                  ),

                  SizedBox(height: 18.h),

                  // Document uploads
                  _sectionTitle('document_uploads'.tr),
                  _workIdCard(),
                  SizedBox(height: 16.h),
                  _uploadDrop(
                    title: 'nid_front_star'.tr,
                    subtitle: 'nid_front_hint'.tr,
                    onTap: controller.pickNidFront,
                    isUploadedRx: controller.nidFrontPath,
                  ),
                  SizedBox(height: 12.h),
                  _uploadDrop(
                    title: 'nid_back_star'.tr,
                    subtitle: 'nid_back_hint'.tr,
                    onTap: controller.pickNidBack,
                    isUploadedRx: controller.nidBackPath,
                  ),
                  SizedBox(height: 8.h),
                ],
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 12.h),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE53935),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                    onPressed: controller.confirmBeforeSubmit,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'update'.tr,
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Icon(Icons.arrow_forward_rounded),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- UI pieces ----------
  InputDecoration _inputDecoration({String? hint}) => InputDecoration(
    hintText: hint,
    isDense: true,
    contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
  );

  Widget _sectionTitle(String text) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        text,
        style: TextStyle(
          fontSize: 13.sp,
          fontWeight: FontWeight.w700,
          color: const Color(0xFF111827),
        ),
      ),
      SizedBox(height: 8.h),
      const Divider(height: 1),
      SizedBox(height: 8.h),
    ],
  );

  Widget _fieldLabel(String text) => Padding(
    padding: EdgeInsets.only(bottom: 6.h),
    child: Text(
      text,
      style: TextStyle(fontSize: 12.sp, color: const Color(0xFF6B7280)),
    ),
  );

  Widget _workIdCard() {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAF7),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'work_id_upload_title'.tr,
            style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w700),
          ),
          SizedBox(height: 4.h),
          Text(
            'work_id_upload_desc'.tr,
            style: TextStyle(fontSize: 11.sp, color: const Color(0xFF6B7280)),
          ),
          SizedBox(height: 10.h),
          _uploadDrop(
            title: '',
            subtitle: 'drag_or_browse'.tr,
            onTap: controller.pickWorkId,
            isUploadedRx: controller.workIdPath,
            showTitle: false,
            dashed: true,
            maxNote: 'only_img_10mb'.tr,
          ),
        ],
      ),
    );
  }

  Widget _uploadDrop({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required RxnString isUploadedRx,
    bool showTitle = true,
    bool dashed = true,
    String? maxNote,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showTitle)
          Text(
            title,
            style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w700),
          ),
        if (showTitle) SizedBox(height: 6.h),
        Obx(() {
          final uploaded = isUploadedRx.value != null;
          return InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(12.r),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 18.h),
              decoration: BoxDecoration(
                color: const Color(0xFFFDFEFE),
                borderRadius: BorderRadius.circular(12.r),
                border: dashed
                    ? Border.all(
                        color: const Color(0xFF16A34A),
                        width: 1,
                        strokeAlign: BorderSide.strokeAlignOutside,
                      )
                    : Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 18.r,
                    backgroundColor: const Color(0xFFFFEEF0),
                    child: Icon(
                      uploaded
                          ? Icons.check_rounded
                          : Icons.cloud_upload_outlined,
                      color: uploaded
                          ? const Color(0xFF16A34A)
                          : const Color(0xFFE53935),
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    uploaded ? 'uploaded_success'.tr : subtitle,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: uploaded
                          ? const Color(0xFF16A34A)
                          : const Color(0xFF6B7280),
                      fontWeight: uploaded ? FontWeight.w700 : FontWeight.w400,
                    ),
                  ),
                  if (maxNote != null) ...[
                    SizedBox(height: 6.h),
                    Text(
                      maxNote,
                      style: TextStyle(
                        fontSize: 11.sp,
                        color: const Color(0xFF9CA3AF),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}
