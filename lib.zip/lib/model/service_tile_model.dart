class ServiceTile {
  final String code; // use to route
  final String asset;
  final String titleKey;
  ServiceTile(this.code, this.asset, this.titleKey);
}
