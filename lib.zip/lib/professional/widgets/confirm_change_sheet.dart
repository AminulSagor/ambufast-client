import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class ConfirmChangeSheet extends StatelessWidget {
  const ConfirmChangeSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
          padding: EdgeInsets.fromLTRB(12.w, 0, 12.w, 12.h),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.r),
            child: Padding(
              padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 16.h),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // grab handle
                  Container(
                    width: 56.w,
                    height: 5.h,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE5E7EB),
                      borderRadius: BorderRadius.circular(3.r),
                    ),
                  ),
                  SizedBox(height: 12.h),

                  // Warning icon
                  CircleAvatar(
                    radius: 26.r,
                    backgroundColor: const Color(0xFFFFE5E7),
                    child: Icon(
                      Icons.error_outline_rounded,
                      color: const Color(0xFFE53935),
                      size: 28.sp,
                    ),
                  ),
                  SizedBox(height: 12.h),

                  // Title
                  Text(
                    'confirm_change_title'.tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 10.h),

                  // Intro
                  Text(
                    'confirm_change_intro'.tr,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 13.sp,
                      color: const Color(0xFF374151),
                    ),
                  ),
                  SizedBox(height: 10.h),

                  // bullets
                  _bullet('confirm_point_1'.tr),
                  _bullet('confirm_point_2'.tr),
                  _bullet('confirm_point_3'.tr),
                  SizedBox(height: 12.h),

                  // Important notes
                  Row(
                    children: [
                      Icon(
                        Icons.priority_high_rounded,
                        color: const Color(0xFFE11D48),
                        size: 18.sp,
                      ),
                      SizedBox(width: 6.w),
                      Text(
                        'important_notes'.tr,
                        style: TextStyle(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFE11D48),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 6.h),
                  _bullet('note_1'.tr, danger: true),
                  _bullet('note_2'.tr, danger: true),
                  _bullet('note_3'.tr, danger: true),
                  SizedBox(height: 16.h),

                  // CTA buttons
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE53935),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                      ),
                      onPressed: () => Get.back(result: true),
                      child: Text(
                        'submit_for_review'.tr,
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10.h),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFE5E7EB)),
                        backgroundColor: const Color(0xFFF3F4F6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                      ),
                      onPressed: () => Get.back(result: false),
                      child: Text(
                        'go_back'.tr,
                        style: TextStyle(
                          fontSize: 15.sp,
                          color: const Color(0xFF111827),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _bullet(String text, {bool danger = false}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '•  ',
            style: TextStyle(
              color: danger ? const Color(0xFFE11D48) : const Color(0xFF111827),
              fontSize: 14.sp,
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 13.sp,
                color: danger
                    ? const Color(0xFFE11D48)
                    : const Color(0xFF374151),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
