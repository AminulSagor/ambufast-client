import 'package:ambufast/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'professional_info_controller.dart';

class ProfessionalInfoView extends GetView<ProfessionalInfoController> {
  const ProfessionalInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: Text(
          'professional_info_title'.tr,
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: neutral700,
          ),
        ),
      ),
      body: Obx(() {
        final info = controller.info.value;
        final isReview = controller.underReview.value;
        final isNotApproved = controller.notApproved.value;
        return Column(
          children: [
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(16.w),
                children: [
                  // NEW: Under-review info card
                  if (isReview) _underReviewCard(),
                  if (isReview) SizedBox(height: 12.h),

                  if (isNotApproved) _notApprovedCard(), // NEW pink card
                  if (isNotApproved) SizedBox(height: 12.h),

                  _box('affiliation_type'.tr, info.affiliationType),
                  12.h.verticalSpace,
                  _box('org_business_name'.tr, info.organisationName),
                  12.h.verticalSpace,
                  _box('your_role'.tr, info.role),
                  12.h.verticalSpace,
                  _box('zone_area'.tr, info.zone),
                  12.h.verticalSpace,

                  _uploadStatus('work_id'.tr, info.workIdPath != null),
                  12.h.verticalSpace,
                  _uploadStatus('nid_front'.tr, info.nidFrontPath != null),
                  12.h.verticalSpace,
                  _uploadStatus('nid_back'.tr, info.nidBackPath != null),
                ],
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 12.h),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE53935),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                    onPressed: isReview ? null : controller.goToEdit,
                    child: Text(
                      'edit'.tr,
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _box(String label, String value) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F6F7),
        borderRadius: BorderRadius.circular(6.r),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14.sp,
                color: neutralBase,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: neutral800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _uploadStatus(String title, bool uploaded) {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: neutral100,
        borderRadius: BorderRadius.circular(6.r),
      ),
      child: Row(
        children: [
          const Icon(Icons.description_outlined, color: neutral600),
          SizedBox(width: 10.w),
          Expanded(
            child: Text(title, style: TextStyle(fontSize: 14.sp)),
          ),
          Icon(
            uploaded ? Icons.cloud_done_rounded : Icons.cloud_upload_rounded,
            color: uploaded ? const Color(0xFF16A34A) : const Color(0xFF9CA3AF),
          ),
        ],
      ),
    );
  }

  Widget _underReviewCard() {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7E6),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: const Color(0xFFFFE3B3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: Color(0xFFB45309)),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'under_review_title'.tr,
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFB45309),
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  'under_review_desc'.tr,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: const Color(0xFF7C2D12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _notApprovedCard() {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFFEEF2), // light pink
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: const Color(0xFFF8C7D3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: Color(0xFF9B1C1C)),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'docs_not_approved_title'.tr,
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF9B1C1C),
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  'docs_not_approved_desc'.tr,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: const Color(0xFF7F1D1D),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
