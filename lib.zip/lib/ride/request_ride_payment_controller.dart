import 'package:ambufast/dialog_box/payment_option_dialogbox.dart';
import 'package:ambufast/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RequestRidePaymentController extends GetxController {
  late final TextEditingController couponController;

  var isCouponApplied = false.obs;
  var appliedCouponCode = ''.obs;
  var discountAmount = '20'.obs;

  @override
  void onInit() {
    super.onInit();
    couponController = TextEditingController();
  }

  void applyCoupon() {
    if (couponController.text.isNotEmpty) {
      // Set the state
      appliedCouponCode.value = couponController.text.toUpperCase();
      isCouponApplied.value = true;
      couponController.clear(); // Clear the input field
      Get.focusScope?.unfocus(); // Hide the keyboard
    } else {
      Get.snackbar('Error', 'Please enter a coupon code');
    }
  }

  void removeCoupon() {
    // Reset the state
    isCouponApplied.value = false;
    appliedCouponCode.value = '';
  }

  void processPayment() {
    // Get.back(); // Close the screen
    Get.dialog(
      PaymentOptionDialogbox(
        onSelect: () {
          Get.toNamed(
            Routes.bkashPayment,
            arguments: {'paymentFor': 'ride_now'},
          );
        },
      ),
    );
  }

  @override
  void onClose() {
    couponController.dispose();
    super.onClose();
  }
}
