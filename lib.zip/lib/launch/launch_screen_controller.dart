// lib/modules/launch/launch_screen_controller.dart
import 'package:get/get.dart';

class LaunchScreenController extends GetxController {
  // Add any state or logic for your launch/welcome screen
}
